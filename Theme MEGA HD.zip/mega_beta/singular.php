<?php get_header(); the_post(); ?>
<main class="wrap" style="background: #FFF; border-radius: 10px; padding: 30px 50px; margin-top: 50px;"> 
	<?php the_content(); ?>
</main>
<?php get_footer(); ?>