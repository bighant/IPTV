<div class="searchBar">
	<input type="text" placeholder="<?php _e('Search for movies or tvshows','mega'); ?>">
	<div class="searchBtn" onclick="showSearchBar()">
		<?php get_template_part('assets/img/icone/search'); ?>
	</div>
</div>